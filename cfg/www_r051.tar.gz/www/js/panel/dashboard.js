var lastUnreadIds = "";
(function ($) {
  $.fn.objdashboard = function (oInit) {
    var gWanConfigProto;
    var noSim = false;
    var netLock = false;
    var pinLock = false;
    var internetDisabled = false;
    this.onLoad = function (flag) {
      if (flag) {
        $("#mainColumn").html(CallHtmlFile("html/dashboard.html"));
        LocalAllElement();
        $("#lChangeConnStatus").click(function () {
          var configMap = new Map();
          configMap.put("RGW/wan/connect_switch/proto", gWanConfigProto);
          configMap.put(
            "RGW/wan/connect_switch/dial_switch",
            $(this).attr("name")
          );

          PostXml("cm", "connection_switch", configMap);
          GetWanConfig();
          GetLinkContext();
        });

        $("#lt_dashbd_resetTrafficStatistic").click(function () {
          var retXml = PostXml("statistics", "stat_clear_common_data");
          if ("ERROR" == $(retXml).find("setting_response").text()) {
            alert("stat_clear_common_data failed.");
          } else {
            $("#txtRecPackets").text(FormatDataTrafficMinUnitKB(0));
            $("#txtsentPackets").text(FormatDataTrafficMinUnitKB(0));
          }
          setTimeout(GetTrafficStaticInfo, 3000);
        });

        GetTrafficStaticInfo();
        GetSimStatus();
        GetWifiStatus();
        GetLinkContext();
        GetRouterInfo();
        GetWanConfig();
        GetBatteryConfig();
        GetConnectedDeviceInfo();
        GetVersionInfo();
        GetUnReadSms();
      } else {
        GetSimStatus("1");
        GetWifiStatus("1");
        GetLinkContext("1");
        GetRouterInfo("1");
        GetWanConfig("1");
        GetBatteryConfig("1");
        GetConnectedDeviceInfo("1");
        GetVersionInfo("1");
      }
      hideOrShowPdplist();
    };
    function GetUnReadSms() {
      var smsMap = new Map();
      smsMap.put("RGW/sms_info/sms/type", 0);
      smsMap.put("RGW/sms_info/sms/read", 0);
      smsMap.put("RGW/sms_info/sms/location", 2);
      var retXml = PostXmlNoShowWaitBox("sms", "sms.query", smsMap);
      var unreadCount = $(retXml).find("count").text();
      if (unreadCount >= 1) {
        var unReadIds = $(retXml).find("ids").text();

        var newArrs = unReadIds.split(",");
        var lastArrs = lastUnreadIds.split(",");
        var i, j;
        var newCount = 0;
        for (i = 0; i < newArrs.length; i++) {
          var found = false;
          for (j = 0; j < lastArrs.length; j++) {
            if (newArrs[i] == lastArrs[j]) {
              found = true;
              break;
            }
          }
          if (!found) {
            newCount++;
          }
        }
        lastUnreadIds = unReadIds;
        if (newCount > 0) {
          var MessAgeNotification = "";
          if (1 == newCount)
            MessAgeNotification =
              newCount + " " + jQuery.i18n.prop("lsmsOneNewArrivedSMS");
          else
            MessAgeNotification =
              newCount + " " + jQuery.i18n.prop("lsmsMoreNewArrivedSMS");
          showMsgBox(jQuery.i18n.prop("lsmsNotification"), MessAgeNotification);
        }
      }
    }

    function GetEngLteInfo(EngModeFlag, type) {
      if (EngModeFlag == 1) $("#engModeLTEInfo").show();
      else $("#engModeLTEInfo").hide();

      if (EngModeFlag != 1) return;
      var retXml;
      if (type == "1") {
        retXml = PostXml("cm", "get_eng_info", null, "clearInterval");
      } else {
        retXml = PostXml("cm", "get_eng_info");
      }
      if ("OK" == $(retXml).find("response_status").text()) {
        var lte_mcc = $(retXml).find("mcc").text();
        if (lte_mcc == "") $("#div_txtLTE_mcc").hide();
        var lte_mnc = $(retXml).find("mnc").text();
        if (lte_mnc == "") $("#div_txtLTE_mnc").hide();
        var lte_phy_cellid = $(retXml).find("phy_cell_id").text();
        if (lte_phy_cellid == "") $("#div_txtLTE_phy_cellid").hide();
        var lte_cellid = $(retXml).find("cell_id").text();
        if (lte_cellid == "") $("#div_txtLTE_cellid").hide();
        var lte_transmission_mode = $(retXml).find("transmission_mode").text();
        if (lte_transmission_mode == "")
          $("#div_txtLTE_transmission_mode").hide();
        var lte_main_rsrp = $(retXml).find("main_rsrp").text();
        if (lte_main_rsrp == "") $("#div_txtLTE_main_rsrp").hide();
        var lte_diversity_rsrp = $(retXml).find("diversity_rsrp").text();
        if (lte_diversity_rsrp == "") $("#div_txtLTE_diversity_rsrp").hide();
        var lte_main_rsrq = $(retXml).find("main_rsrq").text();
        if (lte_main_rsrq == "") $("#div_txtLTE_main_rsrq").hide();
        var lte_diversity_rsrq = $(retXml).find("diversity_rsrq").text();
        if (lte_diversity_rsrq == "") $("#div_txtLTE_diversity_rsrq").hide();
        var lte_sinr = $(retXml).find("sinr").text();
        if (lte_sinr == "") $("#div_txtLTE_sinr").hide();
        var lte_rssi = $(retXml).find("rssi").text();
        if (lte_rssi == "") $("#div_txtLTE_rssi").hide();

        /**
         *  Additinal Signal Info
         *  Added By: Lyoniel Farase
         *
         */
        var lte_dl_euarfcn = $(retXml).find("dl_euarfcn").text();
        if (lte_dl_euarfcn == "") $("#div_txtLTE_dl_euarfcn").hide();

        var lte_ul_euarfcn = $(retXml).find("ul_euarfcn").text();
        if (lte_ul_euarfcn == "") $("#div_txtLTE_ul_euarfcn").hide();

        var lte_dl_bandwidth = $(retXml).find("dl_bandwidth").text();
        if (lte_dl_bandwidth == "") $("#div_txtLTE_dl_bandwidth").hide();

        var lte_band = $(retXml).find("band").text();
        if (lte_band == "") $("#div_txtLTE_band").hide();

        $("#txtLTE_dl_euarfcn").text(lte_dl_euarfcn);
        $("#txtLTE_ul_euarfcn").text(lte_ul_euarfcn);
        $("#txtLTE_dl_bandwidth").text(lte_dl_bandwidth);
        $("#txtLTE_band").text(lte_band);

        /**
         *
         * End of Additinal Signal Info
         *
         */

        $("#txtLTE_mcc").text(lte_mcc);
        $("#txtLTE_mnc").text(lte_mnc.length == 1 ? "0" + lte_mnc : lte_mnc);
        $("#txtLTE_phy_cellid").text(lte_phy_cellid);
        $("#txtLTE_cellid").text(lte_cellid);
        $("#txtLTE_transmission_mode").text(lte_transmission_mode);

        $("#txtLTE_main_rsrp").text(parseFloat(lte_main_rsrp) - 141 + " dBm");
        $("#txtLTE_diversity_rsrp").text(
          parseFloat(lte_diversity_rsrp) - 141 + " dBm"
        );
        $("#txtLTE_main_rsrq").text(parseFloat(lte_main_rsrq) / 2 - 20 + " dB");
        $("#txtLTE_diversity_rsrq").text(
          parseFloat(lte_diversity_rsrq) / 2 - 20 + " dB"
        );
        $("#txtLTE_sinr").text(lte_sinr + " dB");
        $("#txtLTE_rssi").text(parseFloat(lte_rssi) - 128 + " dBm");
      } else $("#engModeLTEInfo").hide();
    }

    function GetVersionInfo(type) {
      var retXml;
      if (type == "1") {
        retXml = PostXml("version", "get_version", null, "clearInterval");
      } else {
        retXml = PostXml("version", "get_version");
      }
      if ("OK" == $(retXml).find("setting_response").text()) {
        var txtRouterMAC = $(retXml).find("mac_addr").text();
        var txtSoftVersion = $(retXml).find("sw_version").text();
        var txtHardVersion = $(retXml).find("hdware_ver").text();
        var txtBaseBandVersion = $(retXml).find("baseband_version").text();
        if (txtRouterMAC == "") {
          $("#div_txtRouterMAC").hide();
        }
        if (txtSoftVersion == "") {
          $("#div_txtSoftVersion").hide();
        }
        if (txtHardVersion == "") {
          $("#div_txtHardVersion").hide();
        }
        if (txtBaseBandVersion == "") {
          $("#div_txtBaseBandVersion").hide();
        }
        $("#txtRouterMAC").text(txtRouterMAC);
        $("#txtSoftVersion").text(txtSoftVersion);
        $("#txtHardVersion").text(txtHardVersion);
        $("#txtBaseBandVersion").text(txtBaseBandVersion);
      }
    }

    function GetConnectedDeviceInfo(type) {
      var retXml;
      if (type == "1") {
        retXml = PostXml(
          "statistics",
          "get_active_clients_num",
          null,
          "clearInterval"
        );
      } else {
        retXml = PostXml("statistics", "get_active_clients_num");
      }
      document.getElementById("lConnDeviceValue").innerHTML = $(retXml)
        .find("active_clients_num")
        .text();
    }

    function GetBatteryConfig(type) {
      var retXml;
      if (type == "1") {
        retXml = PostXml("charger", "get_chg_info", null, "clearInterval");
      } else {
        retXml = PostXml("charger", "get_chg_info");
      }
      var err = $(retXml).find("error_cause").text();
      var bIsChargernotrun = false;

      if ("3" == err) {
        bIsChargernotrun = true;
      }
      if (bIsChargernotrun) {
        $("#lDashChargeStatus").text(jQuery.i18n.prop("lNoBattery"));
        $("#lDashBatteryQuantity").text(jQuery.i18n.prop("lNoBattery"));
        return;
      }
      var Batterystatus = $(retXml).find("bat_status").text();
      var Batterypercent = $(retXml).find("capacity").text();
      var Battery_connect = $(retXml).find("present").text();
      if (Battery_connect == 0) {
        $("#divbatteryinfo").hide();
        $("#lDashChargeStatus").text(jQuery.i18n.prop("lNoBattery"));
        $("#lDashBatteryQuantity").text(jQuery.i18n.prop("lNoBattery"));
      } else if (Battery_connect == 1) {
        $("#divbatteryinfo").show();
        if (Batterystatus == "0")
          $("#lDashChargeStatus").text(
            jQuery.i18n.prop("lBatteryUnknownError")
          );
        if (Batterystatus == "1")
          $("#lDashChargeStatus").text(jQuery.i18n.prop("lCharging"));
        if (Batterystatus == "2")
          $("#lDashChargeStatus").text(jQuery.i18n.prop("lUncharged"));
        if (Batterystatus == "3")
          $("#lDashChargeStatus").text(
            jQuery.i18n.prop("lBatteryUnchargewithconnect")
          );
        if (Batterystatus == "4")
          $("#lDashChargeStatus").text(jQuery.i18n.prop("lFullycharged"));
        var Battery_charge_percent = Batterypercent + "%";
        $("#lDashBatteryQuantity").text(Battery_charge_percent);
      }
    }

    function GetWanConfig(type) {
      var retXml;
      if (type == "1") {
        retXml = PostXml("cm", "get_wan_configs", null, "clearInterval");
      } else {
        retXml = PostXml("cm", "get_wan_configs");
      }
      gWanConfigProto = $(retXml).find("proto").text();

      if ("cellular" == $(retXml).find("dial_switch").text()) {
        internetDisabled = false;
        $("#lCurConnStatus").text(jQuery.i18n.prop("lt_optEnableSwitch"));
        $("#lChangeConnStatus").text(jQuery.i18n.prop("lt_optDisable"));
        $("#lChangeConnStatus").attr("name", "disabled");
        if (noSim || netLock || pinLock) {
          $("#divInternetPdpList").hide();
        } else {
          $("#divInternetPdpList").show();
        }
      } else {
        internetDisabled = true;
        $("#lCurConnStatus").text(jQuery.i18n.prop("lt_optDisabledSwitch"));
        $("#lChangeConnStatus").text(jQuery.i18n.prop("lt_optEnable"));
        $("#lChangeConnStatus").attr("name", "cellular");
        $("#divInternetPdpList").hide();
      }
      var EngModeFlag = $(retXml).find("eng_mode").text();
      GetEngLteInfo(EngModeFlag, type);
    }
    function GetRouterInfo(type) {
      var retXml;
      if (type == "1") {
        retXml = PostXml(
          "router",
          "router_get_dhcp_settings",
          null,
          "clearInterval"
        );
      } else {
        retXml = PostXml("router", "router_get_dhcp_settings");
      }
      if (1 == $(retXml).find("disabled").text()) {
        $("#imgDhcpServerSwitch").attr("src", "images/status-icon2.png");
        $("#lDhcpServerSwitch").text(jQuery.i18n.prop("lt_optDisabledSwitch"));
      } else {
        $("#imgDhcpServerSwitch").attr("src", "images/status-icon3.png");
        $("#lDhcpServerSwitch").text(jQuery.i18n.prop("lt_optEnableSwitch"));
      }

      if (type == "1") {
        retXml = PostXml("router", "router_get_lan_ip", null, "clearInterval");
      } else {
        retXml = PostXml("router", "router_get_lan_ip");
      }
      $("#txtRouterLanIP").text($(retXml).find("lan_ip").text());
      $("#txtRouterMask").text($(retXml).find("lan_netmask").text());

      if (type == "1") {
        retXml = PostXml("router", "get_router_runtime", null, "clearInterval");
      } else {
        retXml = PostXml("router", "get_router_runtime");
      }
      var days = $(retXml).find("run_days").text();
      var hour = $(retXml).find("run_hours").text();
      var min = $(retXml).find("run_min").text();
      var sec = $(retXml).find("run_sec").text();
      var strRunTime = "";
      if (parseInt(days) > 0) {
        strRunTime = strRunTime + days + jQuery.i18n.prop("ldDay");
      }
      strRunTime = strRunTime + " " + formatTimehhmmss(hour, min, sec);
      $("#txtDashRouterRunTime").text(strRunTime);
    }
    function SetPdpConnectIcon() {
      $("#globeImage").attr("src", "images/globe.png");
      $("#imgGlobalConnArrow").attr("src", "images/con-arrow.png");
    }

    function SetPdpDisconnectIcon() {
      $("#globeImage").attr("src", "images/globe_gr.png");
      $("#imgGlobalConnArrow").attr("src", "images/discon-arrow.png");
    }

    function GetLinkContext(type) {
      var retXml;
      if (type == "1") {
        retXml = PostXml("cm", "get_link_context", null, "clearInterval");
      } else {
        retXml = PostXml("cm", "get_link_context");
      }
      /*************************** parse cellular basic info. **********************/
      imei = $(retXml).find("IMEI").text();
      var dashboard_imei = imei == "" ? "N/A" : imei;
      $("#txtRouterIMEI").text(dashboard_imei);
      var IMSI = $(retXml).find("IMSI").text();
      var phoneNum = $(retXml).find("MSISDN").text();
      if (!noSim) {
        $(".dashbd_phoneNum").show();
        if (phoneNum && phoneNum != "") {
          $("#txtRouterPhoneNum").text(phoneNum);
        } else {
          $("#txtRouterPhoneNum").text("N/A");
        }
      } else {
        $(".dashbd_phoneNum").hide();
      }

      var networkOperate = "";
      if (1 == $(retXml).find("roaming").text()) {
        networkOperate = $(retXml).find("roaming_network_name").text();
        $("#divRoamingStatus").show();
      } else {
        networkOperate = $(retXml).find("network_name").text();
        $("#divRoamingStatus").hide();
      }
      if (networkOperate && networkOperate.startsWith("80")) {
        networkOperate = UniDecode(networkOperate.substr(2));
      }

      if (networkOperate) {
        $("#div_txtNetworkOperator").show();
        if (IMSI.substring(0, 5) == "51503") {
          $("#txtNetworkOperator").text("PLDT");
        } else if (IMSI.substring(0, 5) == "51505") {
          $("#txtNetworkOperator").text("SUN");
        } else {
          $("#txtNetworkOperator").text(networkOperate);
        }
      } else {
        $("#div_txtNetworkOperator").hide();
      }
      //<sys_mode/> <!-- 0: no service  1:2G3G  2:LTE-->
      var cellularSysNetworkMode = $(retXml).find("sys_mode").text();
      //<data_mode/> <!-- 1: GPRS 2: EDGE 9: HSPDA 10: HSUPA 11:HSPA 14: LTE -->
      var cellularDataConnMode = $(retXml).find("data_mode").text();
      if (0 == cellularSysNetworkMode) {
        $("#txtSystemNetworkMode").text(
          jQuery.i18n.prop("lt_dashbd_NoService")
        );
      } else if (1 == cellularSysNetworkMode) {
        if (
          cellularDataConnMode != 1 &&
          cellularDataConnMode != 2 &&
          cellularDataConnMode != 16
        ) {
          //3G
          $("#txtSystemNetworkMode").text("3G");
        } else {
          $("#txtSystemNetworkMode").text("2G");
        }
      } else if (2 == cellularSysNetworkMode) {
        $("#txtSystemNetworkMode").text("4G-LTE");
      }

      switch (cellularDataConnMode) {
        case "1":
        case "2":
          $("#txtDataConnMode").text("2G");
          break;
        case "3":
        case "9":
        case "10":
        case "11":
          $("#txtDataConnMode").text("3G");
          break;
        case "14":
        case "15":
          $("#txtDataConnMode").text("4G-LTE");
          break;
        default:
          $("#txtDataConnMode").text("");
      }

      var rssi = $(retXml).find("rssi").text();
      SetSignalStrength(rssi, cellularSysNetworkMode, cellularDataConnMode);

      /********************************** parse PDP infor. *********************************************/
      $("#txtPdpconnStatus,#txtPdpApn").text("");
      $("#txtPdpIpv4Addr").text("");
      $("#txtPdpIpv4Dns1").text("");
      $("#txtPdpIpv4Dns2").text("");
      $("#txtPdpIpv4GateWay").text("");
      $("#txtPdpIpv4NetMask").text("");
      $("#txtPdpIpv6Addr").text("");
      $("#txtPdpIpv6Dns1").text("");
      $("#txtPdpIpv6Dns2").text("");
      $("#txtPdpIpv6GateWay").text("");
      $("#txtPdpIpv6NetMask").text("");

      $(retXml)
        .find("contextlist")
        .each(function () {
          if ($(this).find("Item") && $(this).find("Item").length > 0) {
            $(this)
              .find("Item")
              .each(function () {
                /*0-disconnect;1-connected;2-connecting*/
                var connetStatus = $(retXml).find("connection_status").text(); //
                /*0- secondary pdp;1-primary pdp*/
                var pdpType = $(retXml).find("pdp_type").text();
                /*0-ipv4v6;1-ipv4;2-ipv6*/
                var ipType = $(retXml).find("ip_type").text();
                if (0 == connetStatus) {
                  $("#txtPdpconnStatus").text(
                    jQuery.i18n.prop("pdpConnStatus_disconnected")
                  );
                  SetPdpDisconnectIcon();
                } else if (1 == connetStatus) {
                  $("#txtPdpconnStatus").text(
                    jQuery.i18n.prop("pdpConnStatus_connected")
                  );
                  SetPdpConnectIcon();
                } else if (2 == connetStatus) {
                  $("#txtPdpconnStatus").text(
                    jQuery.i18n.prop("pdpConnStatus_connecting")
                  );
                  SetPdpDisconnectIcon();
                }

                if (2 == cellularSysNetworkMode) {
                  /*LTE*/
                  var lteApn = $(retXml).find("lte_apn").text();
                  if ("" == lteApn) {
                    $("#txtPdpApn").text($(retXml).find("apn").text());
                  } else {
                    $("#txtPdpApn").text($(retXml).find("lte_apn").text());
                  }
                } else {
                  $("#txtPdpApn").text($(retXml).find("apn").text());
                }

                $("#txtPdpIpv4Addr").text($(retXml).find("ipv4_ip").text());
                $("#txtPdpIpv4Dns1").text($(retXml).find("ipv4_dns1").text());
                $("#txtPdpIpv4Dns2").text($(retXml).find("ipv4_dns2").text());
                $("#txtPdpIpv4GateWay").text(
                  $(retXml).find("ipv4_gateway").text()
                );
                $("#txtPdpIpv4NetMask").text(
                  $(retXml).find("ipv4_submask").text()
                );

                $("#txtPdpIpv6Addr").text($(retXml).find("ipv6_ip").text());
                $("#txtPdpIpv6Dns1").text($(retXml).find("ipv6_dns1").text());
                $("#txtPdpIpv6Dns2").text($(retXml).find("ipv6_dns2").text());
                $("#txtPdpIpv6GateWay").text(
                  $(retXml).find("ipv6_gateway").text()
                );
                $("#txtPdpIpv6NetMask").text(
                  $(retXml).find("ipv6_submask").text()
                );

                if (0 == ipType) {
                  $("#pdpIpv4Info").show();
                  $("#pdpIpv6Info").show();
                } else if (1 == ipType) {
                  $("#pdpIpv4Info").show();
                  $("#pdpIpv6Info").hide();
                } else if (2 == ipType) {
                  $("#pdpIpv4Info").hide();
                  $("#pdpIpv6Info").show();
                }
              });
          } else {
            SetPdpDisconnectIcon();
          }
        });
    }
    function GetSimStatus(type) {
      $("#divSimCardAbsent").hide();
      $("#divRequiredPinPuk").hide();
      $("#divCellularConn").hide();
      $("#divNetworkLocked").hide();
      var retXml;
      if (type == "1") {
        retXml = PostXml("sim", "get_sim_status", null, "clearInterval");
      } else {
        retXml = PostXml("sim", "get_sim_status");
      }
      if ("OK" != $(retXml).find("setting_response").text()) {
        //alert("Get Sim Status failed.");
        //return;
      }
      //sim_status: <!--0: sim absent 1:sim present  2: sim error 3: unknown error-->
      //pin_status: <!--0: unkown  1: detected 2: need pin 3: need puk 5: ready-->
      //pn_status: <!--0: unLock    1: Lock net PN     2: Lock net PUK-->
      var simStatus = $(retXml).find("sim_status").text();
      var pinStatus = $(retXml).find("pin_status").text();
      var pnStatus = $(retXml).find("pn_status").text();
      if (0 == simStatus) {
        noSim = true;
        $("#divSimCardAbsent").show();
        $("#divInternetPdpList").hide();
        $("#mTraffic_Statistical").hide(); //hide traffic statics area if no SIM
        $(".homeBox").css("min-height", "150px");
        $("#txtSimStatus").text(jQuery.i18n.prop("lSimStatusAbsent"));
      } else if (1 == simStatus) {
        noSim = false;
        $("#divNetworkLocked").hide();
        $("#divInternetPdpList").show();
        if (2 == pinStatus) {
          pinLock = true;
          $("#divRequiredPinPuk").show();
          $("#txtPinPuk").text("PIN");
          $("#mTraffic_Statistical").hide();
          $("#divInternetPdpList").hide();
        } else if (3 == pinStatus) {
          pinLock = true;
          $("#divRequiredPinPuk").show();
          $("#txtPinPuk").text("PUK");
        } else if (4 == pinStatus) {
          pinLock = false; //
          var perso_substate = $(retXml).find("perso_substate").text();
          if (perso_substate >= 3 && perso_substate <= 12) {
            netLock = true;
            $("#divNetworkLocked").show();
            $("#divInternetPdpList").hide();
            $("#lt_txtNetLocked").text("Invalid Sim");
          }
        } else {
          pinLock = false;
          netLock = false;
          $("#divCellularConn").show();
        }
      } else if (2 == simStatus) {
        noSim = false;
        $("#divSimCardAbsent").show();
        $("#txtSimStatus").text(jQuery.i18n.prop("lSimStatusError"));
      } else if (3 == simStatus) {
        noSim = false;
        $("#divSimCardAbsent").show();
        $("#txtSimStatus").text(jQuery.i18n.prop("lSimStatusUnknownError"));
      }
    }
    function GetWifiStatus(type) {
      var retXml;
      if (type == "1") {
        retXml = PostXml("wireless", "wifi_get_detail", null, "clearInterval");
      } else {
        retXml = PostXml("wireless", "wifi_get_detail");
      }
      var wifi24GStatus, wifi5GStatus;
      $(retXml)
        .find("wifi_if_24G")
        .each(function () {
          wifi24GStatus = $(this).find("switch").text();
        });
      $(retXml)
        .find("wifi_if_5G")
        .each(function () {
          wifi5GStatus = $(this).find("switch").text();
        });

      if (wifi_only_2G == "1" && "off" == wifi24GStatus) {
        $("#lWLANStatus").text(jQuery.i18n.prop("lt_optDisabledSwitch"));
        $("#imgWifiConnStatus").attr("src", "images/status-icon2.png");
        $("#divWifiSet").hide();
        $("#imgWifiConnArrow").attr("src", "images/discon-arrow.png");
        $("#imgNetwork").attr("src", "images/network_gr.png");
        return;
      }

      if ("off" == wifi24GStatus && "off" == wifi5GStatus) {
        $("#lWLANStatus").text(jQuery.i18n.prop("lt_optDisabledSwitch"));
        $("#imgWifiConnStatus").attr("src", "images/status-icon2.png");
        $("#divWifiSet").hide();
        $("#imgWifiConnArrow").attr("src", "images/discon-arrow.png");
        $("#imgNetwork").attr("src", "images/network_gr.png");
        return;
      }

      $("#imgWifiConnArrow").attr("src", "images/con-arrow.png");
      $("#imgNetwork").attr("src", "images/network.png");

      $("#lWLANStatus").text(jQuery.i18n.prop("lt_optEnableSwitch"));
      $("#imgWifiConnStatus").attr("src", "images/status-icon3.png");
      $("#divWifiSet").show();

      var wifiModeTag;
      if ("on" == wifi24GStatus) {
        wifiModeTag = "wifi_if_24G";
      } else {
        wifiModeTag = "wifi_if_5G";
      }

      $(retXml)
        .find(wifiModeTag)
        .each(function () {
          $("#txtWifiSSID").text($(this).find("ssid0").find("ssid").text());
          if ($(this).find("channel").text() == "0") {
            $("#txtWifiChannel").text(jQuery.i18n.prop("txtWifiChannel_auto"));
          } else {
            $("#txtWifiChannel").text($(this).find("channel").text());
          }
          $("#txtWifiSecMode").text(
            GetAuthType($(this).find("ssid0").find("encryption").text())
          );
        });
    }

    function SetSignalStrength(
      rssi,
      cellularSysNetworkMode,
      cellularDataConnMode
    ) {
      if (0 == cellularSysNetworkMode) {
        document.getElementById("imgSignalStrength").src = "images/signal0.png";
      } else if (1 == cellularSysNetworkMode) {
        //GSM 2G3G
        if (
          cellularDataConnMode != 1 &&
          cellularDataConnMode != 2 &&
          cellularDataConnMode != 16
        ) {
          //3G
          if (rssi < 22) {
            document.getElementById("imgSignalStrength").src =
              "images/signal0.png";
          } else if (rssi < 27)
            document.getElementById("imgSignalStrength").src =
              "images/signal1.png";
          else if (rssi < 36)
            document.getElementById("imgSignalStrength").src =
              "images/signal2.png";
          else
            document.getElementById("imgSignalStrength").src =
              "images/signal3.png";
        } else {
          //2G
          if (rssi < 6)
            document.getElementById("imgSignalStrength").src =
              "images/signal0.png";
          else if (rssi < 12)
            document.getElementById("imgSignalStrength").src =
              "images/signal1.png";
          else if (rssi < 24)
            document.getElementById("imgSignalStrength").src =
              "images/signal2.png";
          else
            document.getElementById("imgSignalStrength").src =
              "images/signal3.png";
        }
      } else if (2 == cellularSysNetworkMode) {
        //LTE
        if (rssi < 21) {
          document.getElementById("imgSignalStrength").src =
            "images/signal0.png";
        } else if (rssi < 31)
          document.getElementById("imgSignalStrength").src =
            "images/signal1.png";
        else if (rssi < 41)
          document.getElementById("imgSignalStrength").src =
            "images/signal2.png";
        else
          document.getElementById("imgSignalStrength").src =
            "images/signal3.png";
      }
    }
    function hideOrShowPdplist() {
      if (
        noSim == true ||
        netLock == true ||
        pinLock == true ||
        internetDisabled == true
      ) {
        $("#divInternetPdpList").hide();
      }
    }
    function GetAuthType(encryptInfo) {
      var authType;
      switch (encryptInfo) {
        //WPA-PSK
        case "psk+ccmp":
        case "psk+aes":
        case "psk":
        case "psk+tkip":
        case "psk+tkip+ccmp":
        case "psk+tkip+aes":
          authType = "WPA-PSK";
          break;
        //WPA2-PSK
        case "psk2":
        case "psk2+ccmp":
        case "psk2+aes":
        case "psk2+tkip+ccmp":
        case "psk2+tkip+aes":
        case "psk2+tkip":
          authType = jQuery.i18n.prop("lt_wifiSet_WPA2");
          break;
        //WPA/WPA2-MIXED
        /*case "mixed-psk":
                case "mixed-psk+tkip+aes":
                case "mixed-psk+tkip+ccmp":
                case "mixed-psk+aes":
                case "mixed-psk+ccmp":
                	*/
        case "psk-mixed":
        case "psk-mixed+aes":
        case "psk-mixed+ccmp":
        case "psk-mixed+tkip":
        case "psk-mixed+tkip+aes":
        case "psk-mixed+tkip+ccmp":
          authType = jQuery.i18n.prop("lt_wifiSet_WPAWPA2");
          break;
        //MEP
        case "wep":
        case "wep-open":
          authType = jQuery.i18n.prop("lt_wifiSet_WEP");
          break;
        case "none":
          authType = jQuery.i18n.prop("lt_wifiSet_None");
          break;
        default:
          authType = "Unknow Error";
          break;
      }
      return authType;
    }

    function displayConfigViews() {
      if (dashboard_batteryinfo == 0) {
        $("#divbatteryinfo").hide();
      } else {
        $("#divbatteryinfo").show();
      }
    }

    return this.each(function () {
      _dashboardIntervalID = setInterval(
        "g_objContent.onLoad(false)",
        _dashboardInterval
      );
      _dashboradtrafficStaticIntervalID = setInterval(
        "GetTrafficStaticInfo()",
        _dashboradtrafficStaticInterval
      );
    });
  };
})(jQuery);

var recPackets = 0;
var sendPackets = 0;
function GetTrafficStaticInfo() {
  var retXml = PostXml(
    "statistics",
    "stat_get_common_data",
    null,
    "clearInterval"
  );
  if ("ERROR" != $(retXml).find("setting_response").text()) {
    var rx_bytes = $(retXml).find("total_rx_bytes").text();
    var tx_bytes = $(retXml).find("total_tx_bytes").text();
    if (undefined != rx_bytes && "" != rx_bytes) {
      $("#txtRecPackets").text(FormatDataTrafficMinUnitKB(rx_bytes));
      if (recPackets == 0) {
        $("#txtReceivedSpeed").text("0.00KB/s");
        recPackets = rx_bytes;
      } else {
        var useRecPackets = rx_bytes - recPackets;
        useRecPackets = useRecPackets > 0 ? useRecPackets : 0;
        recPackets = rx_bytes;
        $("#txtReceivedSpeed").text(
          FormatDataTrafficMinUnitKB(
            (useRecPackets * 1000) / _dashboradtrafficStaticInterval
          ) + "/s"
        );
      }
    } else {
      $("#txtReceivedSpeed").text("0.00KB/s");
      recPackets = 0;
    }

    if (undefined != tx_bytes && "" != tx_bytes) {
      $("#txtsentPackets").text(FormatDataTrafficMinUnitKB(tx_bytes));
      if (sendPackets == 0) {
        $("#txtSendSpeed").text("0.00KB/s");
        sendPackets = tx_bytes;
      } else {
        var useSendPackets = tx_bytes - sendPackets;
        useSendPackets = useSendPackets > 0 ? useSendPackets : 0;
        sendPackets = tx_bytes;
        $("#txtSendSpeed").text(
          FormatDataTrafficMinUnitKB(
            (useSendPackets * 1000) / _dashboradtrafficStaticInterval
          ) + "/s"
        );
      }
    } else {
      $("#txtSendSpeed").text("0.00KB/s");
      sendPackets = 0;
    }
  }
}
