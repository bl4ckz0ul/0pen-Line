(function ($) {
  $.fn.objManualNetwork = function (InIt) {
    var gLteBgScanTime;
    var needSave = false;

    var lte_band_1 = 1;
    var lte_band_3 = 4;
    var lte_band_5 = 16;
    var lte_band_28 = 134217728;
    var lte_band_40 = 128;
    var lte_band_41 = 256;

    var ril_mode;
    var gsm_band;
    var umts_band;
    var lte_band_l;
    var lte_band_h;
    var band_priority_1;
    var srv_domain;
    var band_priority_2;
    var lte_band_e;

    this.onLoad = function (flag) {
      if (flag) {
        LoadWebPage("html/internet/manual_network.html");
      }

      $("#lt_ManualNet_btnSearchNetwork").click(function () {
        if (!IsSimPresent()) {
          showMsgBox(
            jQuery.i18n.prop("dialog_message_manual_network_title"),
            jQuery.i18n.prop("lsmsSimCardAbsent")
          );
          return;
        }
        var retXml = PostXml("sim", "get_sim_status");
        pinstatus = $(retXml).find("pin_status").text(); //<!--0: unkown  1: detected 2: need pin 3: need puk 5: ready-->
        if (pinstatus == 2) {
          showMsgBox(
            jQuery.i18n.prop("dialog_message_manual_network_title"),
            jQuery.i18n.prop("lPinEnable")
          );
          return;
        }
        SearchNetWork();
      });

      if (manual_network_bgscan_time == 0) {
        $("#BgScanNetwork").hide();
      } else {
        $("#BgScanNetwork").show();
        GetLteBgScanTime();
      }

      $("#BgScanTimedropdown").change(function () {
        needSave = true;
      });
      $("#SelRearchNetworkList").change(function () {
        needSave = true;
      });
      addAutoOption();

      getCurrentBandInfo();
      _manualnetworkSignalRefreshIntervalID = setInterval(function () {
        processSignalStatus();
      }, _manualnetworkSignalRefreshInterval);

      $("#lt_btnApply_band").click(SetCurrentBandInfo);
    };

    var getSignalRate = function (obj, grade) {
      /*
            excellent = 3
            good = 2
            fair = 1
            poor = 0
            https://usatcorp.com/faqs/understanding-lte-signal-strength-values/
        */
      var rate = 0;
      switch (obj) {
        case "rsrp":
          rate = rateRsrp(grade);
          break;
        case "rsrq":
          rate = rateRsrq(grade);
          break;
        case "sinr":
          rate = rateSinr(grade);
          break;
        default:
      }
      return rate;
    };

    var getPercentage = function (grade, min, max, max2) {
      var percentage = ((grade - min) * 100) / (max - min);
      if (percentage > 100) {
        if (typeof max2 !== "undefined") {
          percentage = ((max2 - grade) * 100) / (max2 - max);
          if (percentage < 0) {
            percentage = 0;
          }
        } else {
          percentage = 100;
        }
      } else if (percentage < 0) {
        percentage = 0;
      }
      return percentage;
    };

    var getSignalPercentage = function (obj, gradetxt) {
      gradetxt = gradetxt.replace(/[<=>]/g, "");
      var grade = parseInt(gradetxt);
      var percent = 0;
      switch (obj) {
        case "rsrp":
          percent = getPercentage(grade, -120, -75);
          break;
        case "rsrq":
          percent = getPercentage(grade, -16, 0);
          break;
        case "sinr":
          percent = getPercentage(grade, 0, 20);
          break;
        default:
      }
      return percent;
    };

    var getLoginStatus = function () {
      var resource = "user/heartbeat";
      return getAjax(resource);
    };

    var rateRsrp = function (gradetxt) {
      var grade = parseInt(gradetxt);

      if (grade >= -84) {
        return 3;
      } else if (grade >= -94 && grade <= -85) {
        return 2;
      } else if (grade >= -111 && grade <= -95) {
        return 1;
      } else {
        //15%-
        return 0;
      }
    };

    var rateRsrq = function (gradetxt) {
      var grade = parseInt(gradetxt);

      if (grade >= -4) {
        return 3;
      } else if (grade >= -9 && grade <= -5) {
        return 2;
      } else if (grade >= -13 && grade <= -10) {
        return 1;
      } else {
        return 0;
      }
    };

    var rateSinr = function (gradetxt) {
      var grade = parseInt(gradetxt);

      if (grade >= 13) {
        return 3;
      } else if (grade >= 10 && grade <= 12) {
        //
        return 2;
      } else if (grade >= 7 && grade <= 9) {
        return 1;
      } else {
        return 0;
      }
    };

    function updateSignal(obj, grade) {
      var _id = "#" + obj; //change to class if needed

      var _class = "";
      var _text = "";

      var width = getSignalPercentage(obj, grade) + "%"; //
      var rate = getSignalRate(obj, grade);
      switch (rate) {
        case 3:
          _text = "Excellent";
          break;
        case 2:
          _text = "Good";
          break;
        case 1:
          _text = "Average";
          break;
        case 0:
          _text = "Poor";
          break;
        default:
          _text = "Unknown";
          width = "0px";
      }

      _class = "bar-" + _text.toLowerCase();

      //remove previous bar-* class
      $(_id + " .progress-bar").removeClass(function (i, classname) {
        return (classname.match(/(^|\s)bar-\S+/g) || []).join(" ");
      });
      $(_id + " .progress-bar").width(width);
      $(_id + " .progress-bar").addClass(_class);

      $(_id + " .txt-rate").text(_text);
      $(_id + " .grade").text(grade);
    }

    function processSignalStatus() {
      var retXml;
      retXml = PostXml("cm", "get_eng_info");

      //do something when the server responded
      var band = $(retXml).find("band").text();
      var pci = $(retXml).find("phy_cell_id").text();
      var cell_id = $(retXml).find("cell_id").text();
      var rsrq = $(retXml).find("rsrq").text();
      var rsrp = $(retXml).find("rsrp").text();

      var sinr = $(retXml).find("sinr").text();

      rsrp = parseFloat(rsrp) - 141;
      rsrq = parseFloat(rsrq) / 2 - 20;

      $("#band").text(band);
      $("#pci").text(pci);
      $("#cellid").text(cell_id);
      updateSignal("rsrp", rsrp + " dBm");
      updateSignal("rsrq", rsrq + " dB");
      updateSignal("sinr", sinr + " dB");
    }

    function addAutoOption() {
      var opt_auto = document.createElement("option");
      document.getElementById("SelRearchNetworkList").options.add(opt_auto);
      opt_auto.id = "dropdownAuto";
      opt_auto.text = jQuery.i18n.prop("lt_ManualNet_auto");
      opt_auto.value = "30";
    }

    function GetLteBgScanTime() {
      if (manual_network_bgscan_time == 0) {
        return;
      }
      var retXml = PostXml("util_wan", "get_bgscan_time");
      gLteBgScanTime = $(retXml).find("bgscan_time").text();
      $("#BgScanTimedropdown").val(gLteBgScanTime);
    }

    function SetLteBgScanTime() {
      if (manual_network_bgscan_time == 0) {
        return;
      }
      if (gLteBgScanTime == $("#BgScanTimedropdown").val()) {
        return;
      }

      var configMap = new Map();
      configMap.put("RGW/wan/bgscan_time", $("#BgScanTimedropdown").val());

      PostXml("util_wan", "set_bgscan_time", configMap);
    }

    function IsSimPresent() {
      var retXml = PostXml("sim", "get_sim_status");
      if (1 == $(retXml).find("sim_status").text()) {
        return true;
      }
      return false;
    }

    function SearchNetWork() {
      ShowDlg("ManualScanConfigure", 300, 150);
      $("#lt_ManualNet_btnConfirm").click(function () {
        CloseDlg();
        ShowDlg("PleaseWait", 200, 130);
        $("#lPleaseWait").text(jQuery.i18n.prop("h1PleaseWait"));
        PostXmlAsync("util_wan", "search_network", null, function (xmlDoc) {
          if ("ERROR" == $(xmlDoc).find("setting_response").text()) {
            showMsgBox(
              jQuery.i18n.prop("dialog_message_manual_network_title"),
              jQuery.i18n.prop("dialog_message_manual_network_search_fail")
            );
            return;
          }
          $("#SelRearchNetworkList").empty();
          $(xmlDoc)
            .find("network_list")
            .each(function () {
              $(this)
                .find("Item")
                .each(function () {
                  var network_plmn = $(this).find("plmn").text();
                  var network_name = $(this).find("isp_name").text();
                  var network_act = $(this).find("act").text();

                  var optText = network_name + " " + network_act;
                  var optValue = network_act + "%" + network_plmn;
                  var opt = document.createElement("option");
                  document
                    .getElementById("SelRearchNetworkList")
                    .options.add(opt);
                  opt.text = optText;
                  opt.value = optValue;
                });
            });
          addAutoOption();
          needSave = true;
          CloseDlg();
          showMsgBoxAutoClose(
            jQuery.i18n.prop("dialog_message_manual_network_title"),
            jQuery.i18n.prop("dialog_message_manual_network_search_success")
          );
        });
      });
    }

    function getCurrentBandInfo() {
      var retXml = PostXml("util_wan", "get_currentband_info");
      ril_mode = $(retXml).find("ril_mode").text();
      gsm_band = $(retXml).find("gsm_band").text();
      umts_band = $(retXml).find("umts_band").text();
      lte_band_h = $(retXml).find("lte_band_h").text();
      lte_band_l = $(retXml).find("lte_band_l").text();

      band_priority_1 = $(retXml).find("band_Priority_1").text();
      srv_domain = $(retXml).find("srv_domain").text();
      band_priority_2 = $(retXml).find("band_Priority_2").text();
      lte_band_e = $(retXml).find("lte_band_e").text();

      if (!(ril_mode == 5 || ril_mode == 11)) {
        var lteBand = document.getElementById("LteBand");
        if (lteBand != null && lteBand.style.display != "none")
          lteBand.style.display = "none";
        return;
      }

      if (lte_band_h != 0) {
        var band_h = parseInt(lte_band_h);
        band_h = setBand(band_h, lte_band_41, "lt_ManualNet_lteB41");
        setBand(band_h, lte_band_40, "lt_ManualNet_lteB40");
      }

      if (lte_band_l == 0) return;
      var band_l = parseInt(lte_band_l);
      band_l = setBand(band_l, lte_band_28, "lt_ManualNet_lteB28");
      band_l = setBand(band_l, lte_band_5, "lt_ManualNet_lteB5");
      band_l = setBand(band_l, lte_band_3, "lt_ManualNet_lteB3");
      setBand(band_l, lte_band_1, "lt_ManualNet_lteB1");
    }

    function SetCurrentBandInfo() {
      var band_l =
        addBand(lte_band_1, "lt_ManualNet_lteB1") +
        addBand(lte_band_3, "lt_ManualNet_lteB3") +
        addBand(lte_band_5, "lt_ManualNet_lteB5") +
        addBand(lte_band_28, "lt_ManualNet_lteB28");
      var band_h =
        addBand(lte_band_40, "lt_ManualNet_lteB40") +
        addBand(lte_band_41, "lt_ManualNet_lteB41");

      if (band_l == 0 && band_h == 0) return;
      if (band_l == lte_band_l && band_h == lte_band_h) return;

      var btnApply = document.getElementById("lt_btnApply_band");
      btnApply.disabled = true;

      var optionMap = new Map();
      optionMap.put("RGW/util_wan/ril_mode", ril_mode);
      optionMap.put("RGW/util_wan/gsm_band", gsm_band);
      optionMap.put("RGW/util_wan/umts_band", umts_band);
      optionMap.put("RGW/util_wan/lte_band_h", band_h);
      optionMap.put("RGW/util_wan/lte_band_l", band_l);
      optionMap.put("RGW/util_wan/band_Priority_1", band_priority_1);
      optionMap.put("RGW/util_wan/srv_domain", srv_domain);
      optionMap.put("RGW/util_wan/band_Priority_2", band_priority_2);
      optionMap.put("RGW/util_wan/lte_band_e", lte_band_e);

      var retXml = PostXml("util_wan", "set_currentband_info", optionMap);
      if ($(retXml).find("setting_response").text() == "OK") {
        showMsgBoxAutoClose(
          jQuery.i18n.prop("dialog_message_manual_network_title"),
          jQuery.i18n.prop(
            "dialog_message_manual_network_save_lte_band_success"
          )
        );
      } else {
        showMsgBox(
          jQuery.i18n.prop("dialog_message_manual_network_title"),
          jQuery.i18n.prop("dialog_message_manual_network_save_lte_band_failed")
        );
      }

      clearInterval(_manualnetworkSignalRefreshIntervalID);
      getCurrentBandInfo();

      _manualnetworkSignalRefreshIntervalID = setInterval(function () {
        processSignalStatus();
      }, _manualnetworkSignalRefreshInterval);
      btnApply.disabled = false;
    }

    function setBand(band_total, band, id) {
      if (band_total < band) return band_total;
      var checkbox = document.getElementById(id);
      if (checkbox != null) checkbox.checked = true;
      return band_total - band;
    }

    function addBand(band, id) {
      var c = document.getElementById(id);
      if (c != null && c.checked) return band;
      return 0;
    }

    this.SaveData = function () {
      SetLteBgScanTime();

      if (
        null == $("#SelRearchNetworkList").val() ||
        "" == $("#SelRearchNetworkList").val() ||
        needSave == false
      ) {
        return;
      }
      var configMap = new Map();
      configMap.put("RGW/wan/network_param", $("#SelRearchNetworkList").val());
      var retXml = PostXml("util_wan", "select_network", configMap);

      if ("ERROR" == $(retXml).find("setting_response").text()) {
        showMsgBox(
          jQuery.i18n.prop("dialog_message_manual_network_title"),
          jQuery.i18n.prop(
            "dialog_message_manual_network_save_network_mode_failed"
          )
        );
      } else {
        showMsgBoxAutoClose(
          jQuery.i18n.prop("dialog_message_manual_network_title"),
          jQuery.i18n.prop(
            "dialog_message_manual_network_save_network_mode_success"
          )
        );
      }
      needSave = false;
    };

    return this;
  };
})(jQuery);
